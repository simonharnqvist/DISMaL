from setuptools import setup

setup(
    name='dismal',
    version='0.01',
    packages=['dismal']
)
