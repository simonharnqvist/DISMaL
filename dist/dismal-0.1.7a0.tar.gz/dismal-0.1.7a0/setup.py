from setuptools import setup

setup(
    name='dismal',
    version='v0.1.7-alpha',
    packages=['dismal'],
    install_requires=[
        "iclik"
    ]
)
