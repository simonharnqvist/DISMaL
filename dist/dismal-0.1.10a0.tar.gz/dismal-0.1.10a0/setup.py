from setuptools import setup

setup(
    name='dismal',
    version='v0.1.10-alpha',
    packages=['dismal']
)
